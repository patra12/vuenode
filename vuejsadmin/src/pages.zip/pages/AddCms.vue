<template>
<div>
   <form action method="POST" @submit="checkForm()">
     
       <md-card>
      <md-card-header data-background-color="green">
        <h4 class="title">Add Page</h4>
        <!-- <p class="category">Complete your profile</p> -->
        <router-link to="/cms">
            <img title="Back to CMS list" class="plus" :src="dataBackgroundColor" />
           </router-link>
      </md-card-header>

      <md-card-content>
        <div class="md-layout">
        <div class="md-layout-item md-small-size-100 md-size-100">
            <md-field>
              <label>Title</label>
              <md-input v-model="title" name="title" id="title" type="text"></md-input>
            </md-field>
          </div>
          <div class="md-layout-item md-small-size-100 md-size-100">
            <md-field>
              <label>Alias</label>
              <md-input v-model="alias" type="text"></md-input>
            </md-field>
          </div>
          <div class="md-layout-item md-small-size-100 md-size-100">
           
              <label>Full description</label><br>
              <!-- <md-input v-model="fulldescription" type="email"></md-input> -->
              <vue-editor v-model="fulldescription"></vue-editor>
            
          </div>
          <div class="md-layout-item"><br>
              <label></label>
              <md-input v-model="image" type="file"></md-input>
          </div>
          
          <div class="md-layout-item md-small-size-100 md-size-100">
            <md-field>
              <label>Meta title</label>
              <md-input v-model="metatitle" type="text"></md-input>
            </md-field>
          </div>
          <div class="md-layout-item md-small-size-100 md-size-100">
            <md-field>
              <label>Meta keywords</label>
              <md-input v-model="metakeywords" type="text"></md-input>
            </md-field>
          </div>
          <div class="md-layout-item md-small-size-100 md-size-100">
            <md-field>
              <label>Meta description</label>
              <md-input v-model="metadescription" type="text"></md-input>
            </md-field>
          </div>
                 
          
          <div class="md-layout-item md-size-100 text-right">
            <md-button class="md-raised md-success">Submit</md-button>
          </div>

         
        </div>
      </md-card-content>
    </md-card>
  </form>
</div>
</template>
<script>
import { VueEditor } from "vue2-editor";

export default {
  components: {
    VueEditor
  },
  name: "add-cms",
  props: {
    dataBackgroundColor: {
      type: String,
       default: require("@/assets/img/back.png")
    },
    data: function() {
    return {
      title: "",
      // email: "",
      // phone: "",
      // gender: "",
      // message: "",
      errors: []
    };
  },
    methods: {
    checkForm: function(e) {
      this.errors = [];

      if (!this.title) {
        this.errors.push("Title is required");
      } else {
        if (this.title < 3) {
          this.errors.push("Title must be more than 5 charectures.");
        }
      }

      // if (!this.email) {
      //   this.errors.push("email cannot be empty");
      // }

      // if (!this.phone) {
      //   this.errors.push("phone is required");
      // }

      // if (!this.gender) {
      //   this.errors.push("Gender must requir");
      // }
      // if (!this.message) {
      //   this.errors.push("message is rewuir");
      // } else {
      //   if (this.message.split(" ").length < 10) {
      //     this.errors.push("message should be more than 10 Words");
      //   }
      // }
      e.preventDefault();
    }
  }
  },

  data() {
    return {
      title: null,
      alias: null,
      fulldescription: null,
      image: null,
      metatitle: null,
      metakeywords: null,
      metadescription: null
           
    };
  }
};
</script>
<style scoped>
.plus {
  float: right;
  margin-top: -30px;
  cursor: pointer;
  padding: 0px 3px;
  height: 40px;
  width: 40px;
}
</style>