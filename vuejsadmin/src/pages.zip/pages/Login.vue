<template>
  <form class="a">
    <md-card class="login">
      <md-card-header class="text-center" data-background-color="green">
        <h4 class="title">Login</h4>
      </md-card-header>

      <md-card-content>
        <div class="md-layout">
          <div class="md-layout-item md-small-size-50 md-size-100 text-center">
            <md-field>
              <label>Email </label>
              <md-input v-model="username" placeholder="birja@kusmail.com" value="birja@kusmail.com" type="text"></md-input>
            </md-field>
          </div>
          <div class="md-layout-item md-small-size-50 md-size-100 text-center">
            <md-field>
              <label>Password</label>
              <md-input v-model="password"  placeholder="Password" value="123456" type="password"></md-input>
            </md-field>
          </div>

          <div class="md-layout-item md-size-100 text-center">
            <md-button
              type="submit"
              @click.stop.prevent="submit()"
              class="md-raised md-success"
            >Submit</md-button>
          </div>
        </div>
      </md-card-content>
    </md-card>
  </form>
</template>
<script>
export default {
  name: "Login",
  props: {
    dataBackgroundColor: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      username: null,
      password: null
    };
  },
  methods: {
    submit() {
      this.$router.push("/dashboard");
    }
  }
};
</script>
<style>
.login {
  max-width: 600px;
  margin: auto;
  margin-right: 500px;
  display: block;
  float: right;
}
.a {
  padding: 10% 26%;
}
</style>
